#ifndef __CONSTBUTTON_H__
#define __CONSTBUTTON_H__

#define MAX_BUTTON  30

#endif /* __CONSTBUTTON_H__ */
