/*
 *
 *  (c) COPYRIGHT MIT and INRIA, 1996-2005
 *  Please first read the full copyright statement in file COPYRIGHT.
 *
 */

#ifndef _MESSAGE_WX_H_
#define _MESSAGE_WX_H_

#ifdef _WX
extern wxString TtaConvMessageToWX ( const char * p_message );
#endif /* _WX */ 

#endif /* #define _MESSAGE_WX_H_ */
