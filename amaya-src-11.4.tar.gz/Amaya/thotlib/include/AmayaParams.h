#ifdef _WX

#ifndef __AMAYAPARAMS_H__
#define __AMAYAPARAMS_H__

// this class is used to pass typed multiple parameters
class AmayaParams
{
 public:
  int   param1;
  void *param2;
  void *param3;
  void *param4;
  void *param5;
  void *param6;
  int   param7;
  int   param8;
  int   param9;
  int   param10;
};

#endif /* __AMAYASUBPANELMANAGER_H__ */

#endif /* _WX */
