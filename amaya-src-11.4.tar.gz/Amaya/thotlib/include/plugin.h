/*
 *
 *  (c) COPYRIGHT INRIA, 1996-2005
 *  Please first read the full copyright statement in file COPYRIGHT.
 *
 */

#ifndef _PLUGIN_H_
#define _PLUGIN_H_

#ifndef __CEXTRACT__
extern void TtaCreateFormPlugin (Document document,
			      View view);
#endif /* __CEXTRACT__ */

#endif
