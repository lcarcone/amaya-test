//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Compilers.rc
//
#define COMP_ICON                       101
#define COMP_TOOLBAR                    104
#define COMP_OPEN                       2001
#define COMP_COMPILE                    2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
